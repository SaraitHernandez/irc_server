# irc_server
42 project

## Contributing

See `docs/TEAM_CONVENTIONS.md#change-workflow` for the change workflow (Notion discussion + GitHub PR) and interface change rules.
